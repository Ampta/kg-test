package com.konrad.kbnb.repository;

public class ReservationRepoImpl {

}
