package com.konrad.kbnb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KbnbApplication {

	public static void main(String[] args) {
		SpringApplication.run(KbnbApplication.class, args);
	}

}
