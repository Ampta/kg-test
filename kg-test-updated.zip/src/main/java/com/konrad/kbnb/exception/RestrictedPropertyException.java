package com.konrad.kbnb.exception;

public class RestrictedPropertyException extends RuntimeException{

    public RestrictedPropertyException(String message) {
        super(message);
    }
}
