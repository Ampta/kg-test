package com.konrad.kbnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KbnbApplicationTests {

	@Test
	void contextLoads() {
	}

}
