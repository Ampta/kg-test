package com.konrad.kbnb.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyConfig {
    //TODO: config additions here
}
